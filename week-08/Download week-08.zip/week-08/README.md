# Week 08 - Using External Libraries in Postman

This week explores the power of built-in libraries:
- Lodash for working with complex data
- Moment.js for time-based logic
- CryptoJS for hashing and encryption

Included Files:
- `lesson.md`
- `quiz.md`
- `Lesson 08 - External Libraries.postman_collection.json`
