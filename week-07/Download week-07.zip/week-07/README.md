# Week 07 - Pre-request Scripts in Postman

This week focuses on using the Pre-request Script tab to:
- Generate values dynamically before each request
- Inject tokens, timestamps, or random strings
- Set variables for chaining or debugging

Files included:
- `lesson.md`
- `quiz.md`
- `Lesson 07 - Pre-request Scripts.postman_collection.json`
